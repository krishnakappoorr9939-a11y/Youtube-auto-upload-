import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import multer from "multer";
import fs from "node:fs";
import path from "node:path";
import cron from "node-cron";
import { google } from "googleapis";
import OpenAI from "openai";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json({ limit: "2mb" }));
const PORT = process.env.PORT || 8080;
const DATA = path.resolve("data");
const QUEUE_DIR = path.resolve("queue_files");
fs.mkdirSync(DATA, { recursive: true });
fs.mkdirSync(QUEUE_DIR, { recursive: true });
const TOKENS = path.join(DATA, "channels.demo.json");
const QUEUE = path.join(DATA, "queue.demo.json");
const upload = multer({ dest: QUEUE_DIR, limits: { fileSize: 2 * 1024 * 1024 * 1024 } });
const SCOPES = ["https://www.googleapis.com/auth/youtube.upload", "https://www.googleapis.com/auth/youtube.readonly"];

function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, "utf8")); } catch { return fallback; }
}
function writeJson(file, value) { fs.writeFileSync(file, JSON.stringify(value, null, 2), { mode: 0o600 }); }
function oauth() {
  return new google.auth.OAuth2(process.env.GOOGLE_CLIENT_ID, process.env.GOOGLE_CLIENT_SECRET, process.env.GOOGLE_REDIRECT_URI);
}
function getYoutube(channelId) {
  const saved = readJson(TOKENS, {})[channelId];
  if (!saved?.refresh_token) throw new Error("Channel is not connected.");
  const auth = oauth();
  auth.setCredentials({ refresh_token: saved.refresh_token });
  return google.youtube({ version: "v3", auth });
}
async function uploadQueuedItem(item) {
  const yt = getYoutube(item.channelId);
  const status = { privacyStatus: item.privacyStatus || "private" };
  if (item.publishAt) {
    status.privacyStatus = "private";
    status.publishAt = new Date(item.publishAt).toISOString();
  }
  const result = await yt.videos.insert({
    part: ["snippet", "status"],
    requestBody: {
      snippet: { title: item.title.slice(0, 100), description: (item.description || "").slice(0, 5000), tags: (item.tags || []).slice(0, 500) },
      status
    },
    media: { body: fs.createReadStream(item.filePath) }
  });
  item.videoId = result.data.id;
  item.videoUrl = `https://www.youtube.com/watch?v=${result.data.id}`;
  item.status = "uploaded";
  item.uploadedAt = new Date().toISOString();
  try { fs.unlinkSync(item.filePath); } catch {}
}

app.get("/health", (_req, res) => res.json({ ok: true }));
app.get("/auth/url", (_req, res) => {
  const client = oauth();
  res.json({ url: client.generateAuthUrl({ access_type: "offline", prompt: "consent", scope: SCOPES }) });
});
app.get("/oauth2callback", async (req, res) => {
  try {
    if (!req.query.code) return res.status(400).send("Authorization code missing.");
    const client = oauth();
    const { tokens } = await client.getToken(String(req.query.code));
    client.setCredentials(tokens);
    const yt = google.youtube({ version: "v3", auth: client });
    const result = await yt.channels.list({ part: ["snippet"], mine: true });
    const channel = result.data.items?.[0];
    if (!channel) return res.status(400).send("இந்த Google account-ல் YouTube channel கிடைக்கவில்லை.");
    const all = readJson(TOKENS, {});
    all[channel.id] = {
      channelId: channel.id,
      title: channel.snippet?.title || "YouTube channel",
      refresh_token: tokens.refresh_token || all[channel.id]?.refresh_token,
      connectedAt: new Date().toISOString()
    };
    if (!all[channel.id].refresh_token) return res.status(400).send("Refresh token கிடைக்கவில்லை. Google account permissions-ல் app access நீக்கி மீண்டும் connect செய்யவும்.");
    writeJson(TOKENS, all);
    res.send("YouTube channel இணைக்கப்பட்டது. App-க்கு திரும்பவும்.");
  } catch (e) { console.error(e); res.status(500).send("Channel connect செய்ய முடியவில்லை."); }
});
app.get("/channels", (_req, res) => {
  const channels = Object.values(readJson(TOKENS, {})).map(({ channelId, title }) => ({ channelId, title }));
  res.json({ channels });
});
app.post("/metadata", async (req, res) => {
  try {
    const { topic, language = "Tamil" } = req.body || {};
    if (!topic?.trim()) return res.status(400).json({ error: "Video topic தேவை." });
    if (!process.env.OPENAI_API_KEY) {
      return res.json({
        title: topic.slice(0, 95),
        description: `${topic}\n\nமேலும் Kabaddi வீடியோக்களுக்கு Subscribe செய்யுங்கள்.\n\n#Kabaddi #KabaddiShorts`,
        tags: ["kabaddi", "kabaddi shorts", "tamil kabaddi", "sports", "shorts"]
      });
    }
    const ai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const out = await ai.chat.completions.create({
      model: "gpt-4o-mini",
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: "Create accurate YouTube metadata. Do not invent facts. Return JSON: title string, description string, tags array of strings. Avoid keyword stuffing." },
        { role: "user", content: `Language: ${language}\nVideo topic: ${topic}` }
      ]
    });
    res.json(JSON.parse(out.choices[0].message.content || "{}"));
  } catch (e) { console.error(e); res.status(500).json({ error: "Metadata உருவாக்க முடியவில்லை." }); }
});
app.post("/queue", upload.single("video"), (req, res) => {
  const filePath = req.file?.path;
  try {
    const { channelId, title, description = "", tags = "[]", privacyStatus = "private", uploadTime = "18:00" } = req.body;
    if (!req.file || !channelId || !title) return res.status(400).json({ error: "Video, channel, title அவசியம்." });
    const tokens = readJson(TOKENS, {});
    if (!tokens[channelId]) return res.status(400).json({ error: "இந்த channel connect செய்யப்படவில்லை." });
    if (!/^\d{2}:\d{2}$/.test(uploadTime)) return res.status(400).json({ error: "நேரம் HH:MM வடிவில் இருக்க வேண்டும்." });
    const parsedTags = JSON.parse(tags);
    const queue = readJson(QUEUE, []);
    const item = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      channelId, title: String(title).slice(0, 100), description: String(description).slice(0, 5000),
      tags: Array.isArray(parsedTags) ? parsedTags : [],
      privacyStatus, uploadTime, filePath,
      status: "queued", createdAt: new Date().toISOString()
    };
    queue.push(item);
    writeJson(QUEUE, queue);
    res.json({ ok: true, item: { id: item.id, title: item.title, uploadTime, status: item.status } });
  } catch (e) {
    if (filePath && fs.existsSync(filePath)) fs.unlinkSync(filePath);
    res.status(400).json({ error: e.message || "Queue-ல் சேர்க்க முடியவில்லை." });
  }
});
app.get("/queue", (_req, res) => {
  const queue = readJson(QUEUE, []).map(({ id, channelId, title, uploadTime, status, videoUrl, createdAt, uploadedAt, error }) =>
    ({ id, channelId, title, uploadTime, status, videoUrl, createdAt, uploadedAt, error }));
  res.json({ queue });
});

// Runs every minute. For each configured time, upload one queued video per channel per calendar day.
cron.schedule("* * * * *", async () => {
  const now = new Date();
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: process.env.TIME_ZONE || "Asia/Kolkata",
    year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23"
  }).formatToParts(now);
  const p = Object.fromEntries(parts.map(x => [x.type, x.value]));
  const localDate = `${p.year}-${p.month}-${p.day}`;
  const localTime = `${p.hour}:${p.minute}`;
  const queue = readJson(QUEUE, []);
  const channelDoneToday = new Set(queue.filter(x => x.status === "uploaded" && x.uploadedAt?.startsWith(localDate)).map(x => x.channelId));
  let changed = false;
  for (const item of queue) {
    if (item.status !== "queued" || item.uploadTime !== localTime || channelDoneToday.has(item.channelId)) continue;
    try {
      await uploadQueuedItem(item);
      channelDoneToday.add(item.channelId);
      console.log(`Uploaded ${item.title}: ${item.videoUrl}`);
    } catch (e) {
      item.status = "failed";
      item.error = e.message;
      console.error("Scheduled upload failed:", e.message);
    }
    changed = true;
  }
  if (changed) writeJson(QUEUE, queue);
}, { timezone: process.env.TIME_ZONE || "Asia/Kolkata" });

app.listen(PORT, () => console.log(`Daily YouTube uploader listening on ${PORT}`));
