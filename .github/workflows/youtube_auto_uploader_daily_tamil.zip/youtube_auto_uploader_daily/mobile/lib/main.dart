import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// Replace with your deployed HTTPS backend address.
const String apiBase = 'https://YOUR-SERVER-DOMAIN';

void main() => runApp(const UploaderApp());

class UploaderApp extends StatelessWidget {
  const UploaderApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'YouTube Daily Auto Uploader',
    theme: ThemeData(colorSchemeSeed: Colors.red, useMaterial3: true),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Map<String, dynamic>> channels = [];
  List<Map<String, dynamic>> queue = [];
  String? channelId;
  File? video;
  String videoName = '';
  String topic = '', title = '', description = '';
  List<String> tags = [];
  String uploadTime = '18:00', visibility = 'private';
  bool busy = false;
  String status = 'முதலில் YouTube channel இணைக்கவும்.';

  Future<void> loadData() async {
    setState(() => busy = true);
    try {
      final a = await http.get(Uri.parse('$apiBase/channels'));
      final b = await http.get(Uri.parse('$apiBase/queue'));
      channels = List<Map<String, dynamic>>.from(jsonDecode(a.body)['channels']);
      queue = List<Map<String, dynamic>>.from(jsonDecode(b.body)['queue']);
      if (channelId == null && channels.isNotEmpty) channelId = channels.first['channelId'];
      status = 'இணைக்கப்பட்ட சேனல்கள்: ${channels.length} | Queue: ${queue.length}';
    } catch (e) { status = 'Server-ஐ தொடர்புகொள்ள முடியவில்லை. Server URL சரிபார்க்கவும்.'; }
    setState(() => busy = false);
  }

  Future<void> connectChannel() async {
    try {
      final r = await http.get(Uri.parse('$apiBase/auth/url'));
      final url = jsonDecode(r.body)['url'] as String;
      setState(() => status = 'இந்த Google authorization link-ஐ Chrome-ல் திறக்கவும்:\n$url');
    } catch (_) { setState(() => status = 'Google connect link கிடைக்கவில்லை.'); }
  }

  Future<void> chooseVideo() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.video);
    if (r?.files.single.path == null) return;
    setState(() {
      video = File(r!.files.single.path!);
      videoName = r.files.single.name;
      if (topic.isEmpty) topic = videoName;
    });
  }

  Future<void> makeMetadata() async {
    if (topic.trim().isEmpty) return;
    setState(() { busy = true; status = 'AI metadata உருவாக்குகிறது...'; });
    try {
      final r = await http.post(Uri.parse('$apiBase/metadata'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'topic': topic, 'language': 'Tamil'}));
      final d = jsonDecode(r.body);
      if (r.statusCode != 200) throw Exception(d['error']);
      setState(() {
        title = d['title'] ?? '';
        description = d['description'] ?? '';
        tags = List<String>.from(d['tags'] ?? []);
        status = 'Title, Description, Tags தயார். சரிபார்க்கவும்.';
      });
    } catch (e) { setState(() => status = 'Metadata பிழை: $e'); }
    setState(() => busy = false);
  }

  Future<void> addToQueue() async {
    if (video == null || channelId == null || title.trim().isEmpty) {
      setState(() => status = 'Video, channel, title ஆகியவற்றைத் தேர்வு செய்யவும்.');
      return;
    }
    if (!RegExp(r'^\d{2}:\d{2}$').hasMatch(uploadTime)) {
      setState(() => status = 'நேரத்தை 24-hour HH:MM வடிவில் கொடுக்கவும். உதா: 18:30');
      return;
    }
    setState(() { busy = true; status = 'Daily Queue-ல் சேர்க்கிறது...'; });
    try {
      final req = http.MultipartRequest('POST', Uri.parse('$apiBase/queue'));
      req.fields.addAll({
        'channelId': channelId!, 'title': title, 'description': description,
        'tags': jsonEncode(tags), 'privacyStatus': visibility, 'uploadTime': uploadTime
      });
      req.files.add(await http.MultipartFile.fromPath('video', video!.path));
      final response = await req.send();
      final body = await response.stream.bytesToString();
      final d = jsonDecode(body);
      if (response.statusCode < 200 || response.statusCode >= 300) throw Exception(d['error'] ?? body);
      setState(() {
        status = 'Daily Queue-ல் சேர்க்கப்பட்டது. Server ${uploadTime}-க்கு upload செய்யும்.';
        video = null; videoName = '';
      });
      await loadData();
    } catch (e) { setState(() => status = 'Queue பிழை: $e'); }
    setState(() => busy = false);
  }

  @override
  void initState() { super.initState(); loadData(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('YouTube Daily Auto Uploader'), actions: [
      IconButton(onPressed: busy ? null : loadData, icon: const Icon(Icons.refresh))
    ]),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      FilledButton.icon(onPressed: busy ? null : connectChannel, icon: const Icon(Icons.add_link), label: const Text('மற்றொரு YouTube Channel இணைக்க')),
      const SizedBox(height: 10),
      DropdownButtonFormField<String>(
        value: channelId,
        decoration: const InputDecoration(labelText: 'Upload செய்ய வேண்டிய Channel', border: OutlineInputBorder()),
        items: channels.map((c) => DropdownMenuItem<String>(value: c['channelId'], child: Text(c['title'] ?? 'Channel'))).toList(),
        onChanged: (v) => setState(() => channelId = v),
      ),
      const SizedBox(height: 16),
      FilledButton.tonalIcon(onPressed: busy ? null : chooseVideo, icon: const Icon(Icons.video_file), label: const Text('Video தேர்வு செய்யவும்')),
      if (videoName.isNotEmpty) Text('தேர்வு செய்தது: $videoName'),
      const SizedBox(height: 10),
      TextField(decoration: const InputDecoration(labelText: 'Video Topic / Filename', border: OutlineInputBorder()), onChanged: (v) => topic = v),
      const SizedBox(height: 10),
      OutlinedButton.icon(onPressed: busy ? null : makeMetadata, icon: const Icon(Icons.auto_awesome), label: const Text('AI Title, Description, Tags உருவாக்கு')),
      const SizedBox(height: 10),
      TextField(decoration: const InputDecoration(labelText: 'Title', border: OutlineInputBorder()), maxLength: 100, onChanged: (v) => title = v),
      const SizedBox(height: 10),
      TextField(decoration: const InputDecoration(labelText: 'Description', border: OutlineInputBorder()), maxLines: 4, onChanged: (v) => description = v),
      const SizedBox(height: 8),
      Text('Tags: ${tags.join(', ')}'),
      const SizedBox(height: 10),
      TextField(
        controller: TextEditingController(text: uploadTime),
        decoration: const InputDecoration(labelText: 'தினசரி Upload நேரம் (IST, HH:MM)', hintText: '18:00', border: OutlineInputBorder()),
        onChanged: (v) => uploadTime = v,
      ),
      const SizedBox(height: 10),
      DropdownButtonFormField<String>(
        value: visibility,
        decoration: const InputDecoration(labelText: 'Visibility', border: OutlineInputBorder()),
        items: const [
          DropdownMenuItem(value: 'private', child: Text('Private (பரிந்துரை)')),
          DropdownMenuItem(value: 'unlisted', child: Text('Unlisted')),
          DropdownMenuItem(value: 'public', child: Text('Public')),
        ],
        onChanged: (v) => setState(() => visibility = v ?? 'private'),
      ),
      const SizedBox(height: 14),
      FilledButton.icon(onPressed: busy ? null : addToQueue, icon: const Icon(Icons.schedule_send), label: const Text('Daily Queue-ல் சேர்')),
      const SizedBox(height: 14),
      Card(child: Padding(padding: const EdgeInsets.all(12), child: SelectableText(status))),
      const SizedBox(height: 12),
      Text('Upload Queue', style: Theme.of(context).textTheme.titleLarge),
      ...queue.map((q) => ListTile(
        contentPadding: EdgeInsets.zero,
        leading: Icon(q['status'] == 'uploaded' ? Icons.check_circle : q['status'] == 'failed' ? Icons.error : Icons.schedule),
        title: Text(q['title'] ?? ''),
        subtitle: Text('${q['uploadTime'] ?? ''} • ${q['status'] ?? ''}${q['videoUrl'] == null ? '' : '\n${q['videoUrl']}'}'),
      )),
      const SizedBox(height: 12),
      const Text('குறிப்பு: தினசரி Upload நடக்க server எப்போதும் இயங்க வேண்டும். வீடியோ upload உரிமை உங்களிடம் இருப்பதை உறுதி செய்யவும்.', style: TextStyle(fontSize: 12)),
    ]),
  );
}
